package ch01;

public class Ch01_1HelloOpencv {

	public static void main(String[] args) {
		System.out.println("Hello OpenCV!");
	}

}
